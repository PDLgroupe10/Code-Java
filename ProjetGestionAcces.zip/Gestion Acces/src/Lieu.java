
public class Lieu {
	
	private String emplacement;
	private int nbr_acces;
	/**
	 * @param emplacement
	 * @param nbr_acces
	 */
	public Lieu(String emplacement, int nbr_acces) {
		this.emplacement = emplacement;
		this.nbr_acces = nbr_acces;
	}
	public String getEmplacement() {
		return emplacement;
	}
	public void setEmplacement(String emplacement) {
		this.emplacement = emplacement;
	}
	public int getNbr_acces() {
		return nbr_acces;
	}
	public void setNbr_acces(int nbr_acces) {
		this.nbr_acces = nbr_acces;
	}
	
}
