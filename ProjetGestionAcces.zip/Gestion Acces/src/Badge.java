
public class Badge {
	
	private String nom;
	private String prenom;
	private String fonction;
	
	/**
	 * @param nom
	 * @param prenom
	 * @param date_nais
	 * @param fonction
	 */
	public Badge(String nom, String prenom, String fonction) {
		this.nom = nom;
		this.prenom = prenom;
		this.fonction = fonction;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getFonction() {
		return fonction;
	}

	public void setFonction(String fonction) {
		this.fonction = fonction;
	}
}
