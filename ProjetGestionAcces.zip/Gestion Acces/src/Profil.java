
public class Profil {
	
	private String lieu;
	private String heure_deb;
	private String heure_fin;
	/**
	 * @param lieu
	 * @param heure_deb
	 * @param heure_fin
	 */
	public Profil(String lieu, String heure_deb, String heure_fin) {
		super();
		this.lieu = lieu;
		this.heure_deb = heure_deb;
		this.heure_fin = heure_fin;
	}
	public String getLieu() {
		return lieu;
	}
	public void setLieu(String lieu) {
		this.lieu = lieu;
	}
	public String getHeure_deb() {
		return heure_deb;
	}
	public void setHeure_deb(String heure_deb) {
		this.heure_deb = heure_deb;
	}
	public String getHeure_fin() {
		return heure_fin;
	}
	public void setHeure_fin(String heure_fin) {
		this.heure_fin = heure_fin;
	}

}
