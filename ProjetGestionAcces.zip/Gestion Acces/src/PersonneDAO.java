import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe d'accès aux données contenues dans la table personne
 * 
 * @author grave - roueche - serais
 * @version 1.2
 * */
public class PersonneDAO extends DAO {

	
	/**
	 * Constructeur de la classe
	 * 
	 */
	public PersonneDAO() {
		super();
	}

	/**
	 * Permet d'ajouter un personne dans la table personne Le mode est auto-commit
	 * par défaut : chaque insertion est validée
	 * 
	 * @param personne
	 *            l'personne à ajouter
	 * @return retourne le nombre de lignes ajoutées dans la table
	 */
	public int ajouter(Personne personne) {
		Connection con = null;
		PreparedStatement ps = null;
		int retour = 0;

		// connexion à la base de données
		try {

			// tentative de connexion
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			// préparation de l'instruction SQL, chaque ? représente une valeur
			// à communiquer dans l'insertion
			// les getters permettent de récupérer les valeurs des attributs
			// souhaités
			ps = con.prepareStatement("INSERT INTO personne (nom, prenom, date_nais, fonction) VALUES (?, ?, ?, ?)");
			ps.setString(1, personne.getNom());
			ps.setString(2, personne.getPrenom());
			ps.setString(3, personne.getDate_nais());
			ps.setString(4, personne.getFonction());

			// Exécution de la requête
			retour = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// fermeture du preparedStatement et de la connexion
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return retour;

	}

	/**
	 * Permet de récupérer un personne à partir de sa référence
	 * 
	 * @param reference
	 *            la référence de l'personne à récupérer
	 * @return 	l'personne trouvé;
	 * 			null si aucun personne ne correspond à cette référence
	 */
	public Personne getPersonne(String nom) {

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Personne retour = null;

		// connexion à la base de données
		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM personne WHERE nom = ? AND prenom = ?");
			ps.setString(1, nom);

			// on exécute la requête
			// rs contient un pointeur situé juste avant la première ligne
			// retournée
			rs = ps.executeQuery();
			// passe à la première (et unique) ligne retournée
			if (rs.next())
				retour = new Personne(rs.getString("nom"),rs.getString("prenom"),
						rs.getString("date_nais"), rs.getString("fonction"));

		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du ResultSet, du PreparedStatement et de la Connexion
			try {
				if (rs != null)
					rs.close();
			} catch (Exception ignore) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return retour;

	}

	/**
	 * Permet de récupérer tous les personnes stockés dans la table personne
	 * 
	 * @return une ArrayList d'Personnes
	 */
	public List<Personne> getListePersonnes() {

		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		List<Personne> retour = new ArrayList<Personne>();

		// connexion à la base de données
		try {

			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("SELECT * FROM personne");

			// on exécute la requête
			rs = ps.executeQuery();
			// on parcourt les lignes du résultat
			while (rs.next())
				retour.add(new Personne(rs.getString("nom"),rs.getString("prenom"),
						rs.getString("date_nais"), rs.getString("fonction")));

		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			// fermeture du rs, du preparedStatement et de la connexion
			try {
				if (rs != null)
					rs.close();
			} catch (Exception ignore) {
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception ignore) {
			}
			try {
				if (con != null)
					con.close();
			} catch (Exception ignore) {
			}
		}
		return retour;

	}

	// main permettant de tester la classe
	public static void main(String[] args) throws SQLException {

		PersonneDAO personneDAO = new PersonneDAO();
		// test de la méthode ajouter
		Personne a1 = new Personne("MAKOSSO", "Adrien", "12/01/1997",
				"Etudiant");
		int retour = personneDAO.ajouter(a1);

		System.out.println(retour + " lignes ajoutées");

		// test de la méthode getPersonne
		Personne a2 = personneDAO.getPersonne("BELOUAH");
		System.out.println(a2);

		// test de la méthode getListePersonnes
		List<Personne> liste = personneDAO.getListePersonnes();
		// affichage des personnes
		for (Personne art : liste) {
			System.out.println(art.toString());
		}

	}
}
