
public class Personne {
	
	private String nom;
	private String prenom;
	private String date_nais;
	private String fonction;
	
	/**
	 * @param nom
	 * @param prenom
	 * @param date_nais
	 * @param fonction
	 */
	public Personne(String nom, String prenom, String date_nais, String fonction) {
		this.nom = nom;
		this.prenom = prenom;
		this.date_nais = date_nais;
		this.fonction = fonction;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getDate_nais() {
		return date_nais;
	}

	public void setDate_nais(String date_nais) {
		this.date_nais = date_nais;
	}

	public String getFonction() {
		return fonction;
	}

	public void setFonction(String fonction) {
		this.fonction = fonction;
	}
	
	public String toString() {
		return "[ " + nom + " - " + prenom
				+ ", " + date_nais + " , " + fonction + " ]";
	}

}
